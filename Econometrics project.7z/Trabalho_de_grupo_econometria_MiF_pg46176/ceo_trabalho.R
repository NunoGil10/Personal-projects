library("tidyverse")
library("haven")
library("jtools")
library(lmtest)
library("car")
library("vtable")
library(patchwork)

setwd("C:/Users/tallm/Desktop/uni/mestrado/econometria/trabalho_econ")
data <- read_dta(file = "CEOSAL1.DTA")

lm1 <- lm(salary ~ roe + ros, data=data)
lm2 <- lm(lsalary ~ lsales + roe + ros, data=data)
lm3 <- lm(lsalary ~ lsales + roe + ros + indus + finance + consprod, data=data)
lm4 <- lm(lsalary ~lsales + roe + ros + indus + finance + utility, data=data)

export_summs(lm1,lm2,lm3,lm4, to.file = "docx", file.name="table.docx")
sumtable(data)


# breusch-pagan tests

bptest(lm1)
bptest(lm2)
bptest(lm3)
bptest(lm4)

# durbin watson tests

durbinWatsonTest(lm1)
durbinWatsonTest(lm2)
durbinWatsonTest(lm3)
durbinWatsonTest(lm4)

# reset tests

resettest(lm1,power=2:3,type="regressor",data=data)
resettest(lm2,power=2:3,type="regressor",data=data)
resettest(lm3,power=2:3,type="regressor",data=data)
resettest(lm4,power=2:3,type="regressor",data=data)


# plotting the graphs between lsalary, lsales & roe

p1 <- data %>% ggplot(data=.,
                mapping = aes( y = lsalary,
                               x = lsales)) +
  geom_point() +
  geom_abline(colour = "blue") +
  labs(x = "Logarithm of sales", y = "Logarithm of salary")

p2 <- data %>% ggplot(data =.,
                      mapping = aes( y = lsalary,
                                     x = roe)) +
  geom_point() +
  geom_abline(colour = "blue") +
  labs(x = "Return on equity", y = "Logarithm of salary")

p1 + p2

# chow test

data_finance1 <- subset(data, finance == 1, select = c(lsalary, lsales, roe, ros))
data_finance0 <- subset(data, finance == 0, select = c(lsalary, lsales, roe, ros))

lm_f1 <- lm(lsalary ~ lsales + roe + ros, data=data_finance1)
lm_f0 <- lm(lsalary ~ lsales + roe + ros, data=data_finance0)

rss_res <- sum(resid(lm2)^2)
rss_f1 <- sum(resid(lm_f1)^2)
rss_f0 <- sum(resid(lm_f0)^2)

# k = 4 number of parameters including the intercept

F_obs <- ((rss_res - rss_f1 - rss_f0)/4)/((rss_f1 + rss_f0)/(209 - 8))
F_obs

F_crit <- qf(0.05, 4, 201, lower.tail=FALSE)

F_crit > F_obs # as this is false, we reject the null hypothesis

confint(lm1)
confint(lm2)
confint(lm3)
confint(lm4)